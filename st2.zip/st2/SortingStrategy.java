import java.util.Arrays;
// SortingStrategy interface
interface SortingStrategy {
    void sort(int[] array);
}