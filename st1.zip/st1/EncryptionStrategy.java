// EncryptionStrategy interface
public interface EncryptionStrategy {
    String encrypt(String plaintext);
}
