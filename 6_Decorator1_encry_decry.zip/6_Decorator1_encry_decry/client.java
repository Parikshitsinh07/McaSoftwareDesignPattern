public class client {
    public static void main(String[] args) {
        String s = "Satyajit PratapSinh zala";
        DataSourceDecorator encoded = new EncryptionDecryptionDecorator(new FileDataSource("Decorator.txt"));
        encoded.writeData(s);
        DataSource ds = new FileDataSource("Decorator.txt");

        System.out.println("Name:");
        System.out.println(s);
        
        System.out.println("Encoded String:");
        System.out.println(ds.readData());

        System.out.println("Decoded String:");
        System.out.println(encoded.readData());
    }
}