// SortingStrategy interface
interface SortingStrategy {
    void sort(int[] array);
}