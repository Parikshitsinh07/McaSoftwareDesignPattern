public interface IO
{
	public void write(String data);
	public String read();


}